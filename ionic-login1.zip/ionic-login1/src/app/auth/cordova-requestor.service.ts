import { CordovaRequestor } from 'ionic-appauth/lib/cordova';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class CordovaRequestorService extends CordovaRequestor {
}
